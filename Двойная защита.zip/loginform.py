from flask_wtf import FlaskForm
from wtforms import StringField, SubmitField
from wtforms.validators import DataRequired


class LoginForm(FlaskForm):
    surname = StringField('Id астронавта', validators=[DataRequired()])
    name = StringField("Пароль астронавта", validators=[DataRequired()])
    edu = StringField('Id капитана', validators=[DataRequired()])
    proffesion = StringField('Пароль капитана', validators=[DataRequired()])
    submit = SubmitField('Доступ')
