from flask import Flask, render_template, redirect
from loginform import LoginForm
app = Flask(__name__)
app.config['SECRET_KEY'] = 'yandexlyceum_secret_key'
result = {}


@app.route('/', methods=['GET', 'POST'])
def login():
    global result
    form = LoginForm()
    if form.validate_on_submit():
        result = {"Id_": form.name.data, "surname": form.surname.data,
                  "edu": form.edu.data, "proff": form.proffesion.data}
        return redirect('/auto_answer')
    return render_template('answer.html', form=form, title='Авторизация')


if __name__ == '__main__':
    app.run(port=8080, host='127.0.0.1')
