from data import db_sess
from data.users import User


if __name__ == '__main__':
    db_sess.global_init("db/users.db")
    cap = User()
    cap.speciality = "research engineer"
    cap.surname = "Scott"
    cap.name = "Ridley"
    cap.age = 21
    cap.position = "captain"
    cap.address = "module_1"
    cap.email = "scott_chief@mars.org"
    doc = User()
    doc.speciality = "Doctor"
    doc.surname = "Ivanov"
    doc.name = "Ivan"
    doc.age = 32
    doc.position = "Crewmate"
    doc.address = "module_2"
    doc.email = "i_am_doctor@mars.org"
    sci = User()
    sci.speciality = "Researcher"
    sci.surname = "Andreev"
    sci.name = "Andrei"
    sci.age = 40
    sci.position = "crewmate"
    sci.address = "module_3"
    sci.email = "Science_is_cool@mars.org"
    bui = User()
    bui.speciality = "Construction_worker"
    bui.surname = "Pavlov"
    bui.name = "Aleksei"
    bui.age = 28
    bui.position = "crewmate"
    bui.email = "I_love_buildings@mars.org"
    base = db_sess.create_session()
    base.add(cap)
    base.commit()

