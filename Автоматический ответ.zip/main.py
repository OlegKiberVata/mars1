from flask import Flask, render_template, redirect
from loginform import LoginForm
app = Flask(__name__)
app.config['SECRET_KEY'] = 'yandexlyceum_secret_key'
result = {}


@app.route('/answer', methods=['GET', 'POST'])
def login():
    global result
    form = LoginForm()
    if form.validate_on_submit():
        result = {"title": "Результат", "name": form.name.data, "surname": form.surname.data, "ready": form.ready.data,
                  "edu": form.edu.data, "proff": form.proffesion.data, "sex": form.sex.data, "motivation": form.motivation.data}
        return redirect('/auto_answer')
    return render_template('answer.html', form=form, title='Авторизация')


@app.route("/auto_answer")
def auto_answer():
    if result:
        return render_template("auto_answer.html", title=result["title"], name=result["name"], surname=result["surname"], ready=result["ready"],
                               education=result["edu"], proffesion=result["proff"], sex=result["sex"], motivation=result["motivation"])
    else:
        return render_template("sorry.html")


if __name__ == '__main__':
    app.run(port=8080, host='127.0.0.1')
